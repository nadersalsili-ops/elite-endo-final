# ⚕ ELITE ENDOCRINOLOGY AI v5.0 — Flutter Mobile App
### Dr. Nader · Clinical Assistant · عيادة

---

## 📋 المتطلبات

- Flutter SDK **≥ 3.3.0**
- Dart SDK **≥ 3.3.0**
- Android Studio / VS Code مع Flutter extension
- Anthropic API Key من [console.anthropic.com](https://console.anthropic.com)

---

## 🚀 تثبيت وتشغيل

```bash
# 1. تثبيت المكتبات
flutter pub get

# 2. تشغيل على Android/iOS
flutter run

# 3. بناء APK للأندرويد
flutter build apk --release

# 4. بناء IPA للآيفون
flutter build ios --release
```

---

## 📱 إعداد الـ Permissions

### Android — `android/app/src/main/AndroidManifest.xml`
أضف قبل `<application>`:
```xml
<uses-permission android:name="android.permission.INTERNET"/>
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>
```

### iOS — `ios/Runner/Info.plist`
أضف داخل `<dict>`:
```xml
<key>NSAppTransportSecurity</key>
<dict>
    <key>NSAllowsArbitraryLoads</key>
    <false/>
    <key>NSExceptionDomains</key>
    <dict>
        <key>anthropic.com</key>
        <dict>
            <key>NSExceptionAllowsInsecureHTTPLoads</key>
            <false/>
            <key>NSIncludesSubdomains</key>
            <true/>
        </dict>
    </dict>
</dict>
```

---

## 🗂 هيكل المشروع

```
lib/
├── main.dart                    ← Entry point + routing
├── models/
│   └── message_model.dart       ← Chat message model
├── services/
│   └── api_service.dart         ← Anthropic SSE streaming
├── utils/
│   ├── app_theme.dart           ← Colors + theme
│   └── system_prompt.dart       ← System prompt + modes + templates
└── screens/
    ├── chat_screen.dart         ← Main chat UI
    └── settings_screen.dart     ← API key management
```

---

## ✨ المميزات

| Feature | Status |
|---------|--------|
| 🔴🟡🟢 Three Analysis Modes | ✅ |
| ⚡ Real-time Streaming | ✅ |
| 🏥 ELITE ENDO v5.0 System Prompt | ✅ |
| 💊 Egyptian Pharma Context | ✅ |
| 📋 6 Clinical Templates | ✅ |
| ⏰ Cairo Time Clock | ✅ |
| 🔒 Secure API Key Storage | ✅ |
| 📋 Copy Response | ✅ |
| ⏹ Stop Generation | ✅ |
| 🌙 Dark Theme | ✅ |
| 🇦🇪 Arabic + English Mixed | ✅ |

---

## 🔑 API Key

1. اذهب إلى [console.anthropic.com](https://console.anthropic.com)
2. Create → API Key
3. افتح التطبيق → Settings (⚙) → أدخل المفتاح
4. المفتاح محفوظ محلياً على جهازك فقط

---

## 📚 References Active

- Williams Endocrinology 14th Ed (2024)
- Oxford Handbook of Endocrinology 4th Ed (2023)  
- ADA Standards of Care 2026
- Endocrine Society Guidelines
- ATA 2023 | KDIGO 2024 | ISPAD 2022
- Egyptian National Growth Charts (2020)
- Egyptian Pharmaceutical Market ✓

---

*ELITE ENDO AI v5.0 | د. نادر | Zero-Hallucination Protocol ACTIVE*
