// lib/models/message_model.dart

enum MessageRole { user, assistant }

class ChatMessage {
  final String id;
  final MessageRole role;
  String content;
  final DateTime timestamp;
  bool isStreaming;
  bool isError;

  ChatMessage({
    required this.id,
    required this.role,
    required this.content,
    required this.timestamp,
    this.isStreaming = false,
    this.isError = false,
  });

  Map<String, dynamic> toApi() => {
        'role': role == MessageRole.user ? 'user' : 'assistant',
        'content': content,
      };
}
