// lib/screens/settings_screen.dart

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../utils/app_theme.dart';

class SettingsScreen extends StatefulWidget {
  final String? currentKey;
  const SettingsScreen({super.key, this.currentKey});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late final TextEditingController _keyCtrl;
  bool _obscure = true;
  bool _saving  = false;
  String? _feedback;

  @override
  void initState() {
    super.initState();
    _keyCtrl = TextEditingController(text: widget.currentKey ?? '');
  }

  @override
  void dispose() {
    _keyCtrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final key = _keyCtrl.text.trim();
    if (!key.startsWith('sk-ant-')) {
      setState(() => _feedback = '⚠️ المفتاح يجب أن يبدأ بـ sk-ant-');
      return;
    }
    setState(() { _saving = true; _feedback = null; });
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('anthropic_api_key', key);
    setState(() { _saving = false; _feedback = '✅ تم الحفظ بنجاح'; });
    await Future.delayed(const Duration(milliseconds: 800));
    if (mounted) Navigator.of(context).pop(key);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.background,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: AppColors.textSecondary, size: 18),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text(
          'API Key Settings',
          style: GoogleFonts.syne(
            fontSize: 16, fontWeight: FontWeight.w800, color: AppColors.textPrimary,
          ),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(height: 1, color: AppColors.border),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Card
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: AppColors.surface,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: AppColors.border),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Icon + title
                    Row(
                      children: [
                        Container(
                          width: 42, height: 42,
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              colors: [Color(0xFF1AD4AA), Color(0xFF0087CC)],
                            ),
                            borderRadius: BorderRadius.circular(11),
                          ),
                          child: const Center(
                            child: Text('⚕', style: TextStyle(fontSize: 22)),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Anthropic API Key',
                                style: GoogleFonts.syne(
                                  fontSize: 15, fontWeight: FontWeight.w800,
                                  color: AppColors.textPrimary,
                                ),
                              ),
                              Text(
                                'مطلوب لتشغيل ELITE ENDO AI v5.0',
                                style: GoogleFonts.ibmPlexSans(
                                  fontSize: 11, color: AppColors.textSecondary,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),

                    // Instructions
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: const Color(0x0A00D4AA),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: const Color(0x1400D4AA)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            '📋 كيفية الحصول على API Key:',
                            style: GoogleFonts.ibmPlexSans(
                              fontSize: 11.5, fontWeight: FontWeight.w600,
                              color: AppColors.accent,
                            ),
                          ),
                          const SizedBox(height: 6),
                          _step('1', 'اذهب إلى console.anthropic.com'),
                          _step('2', 'سجّل دخول أو أنشئ حساباً'),
                          _step('3', 'API Keys → Create Key'),
                          _step('4', 'انسخ المفتاح (يبدأ بـ sk-ant-)'),
                        ],
                      ),
                    ),
                    const SizedBox(height: 18),

                    // Input
                    TextField(
                      controller: _keyCtrl,
                      obscureText: _obscure,
                      style: GoogleFonts.ibmPlexMono(
                        fontSize: 12, color: AppColors.textPrimary,
                      ),
                      decoration: InputDecoration(
                        hintText: 'sk-ant-api03-...',
                        filled: true,
                        fillColor: const Color(0xFF070D1A),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: const BorderSide(color: AppColors.border),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: const BorderSide(color: AppColors.border),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: const BorderSide(color: AppColors.accent, width: 1.5),
                        ),
                        suffixIcon: IconButton(
                          icon: Icon(
                            _obscure ? Icons.visibility_off : Icons.visibility,
                            color: AppColors.textSecondary,
                            size: 18,
                          ),
                          onPressed: () => setState(() => _obscure = !_obscure),
                        ),
                      ),
                    ),

                    if (_feedback != null) ...[
                      const SizedBox(height: 10),
                      Text(
                        _feedback!,
                        style: GoogleFonts.ibmPlexSans(
                          fontSize: 11.5,
                          color: _feedback!.startsWith('✅')
                              ? AppColors.accent
                              : AppColors.errorColor,
                        ),
                      ),
                    ],

                    const SizedBox(height: 18),

                    // Save button
                    SizedBox(
                      width: double.infinity,
                      height: 46,
                      child: ElevatedButton(
                        onPressed: _saving ? null : _save,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0x2200D4AA),
                          foregroundColor: AppColors.accent,
                          side: const BorderSide(color: AppColors.border),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                          elevation: 0,
                        ),
                        child: _saving
                            ? const SizedBox(
                                width: 18, height: 18,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2, color: AppColors.accent,
                                ),
                              )
                            : Text(
                                'حفظ وتفعيل',
                                style: GoogleFonts.syne(
                                  fontSize: 14, fontWeight: FontWeight.w700,
                                ),
                              ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              // Security note
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: const Color(0x08FF4757),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: const Color(0x22FF4757)),
                ),
                child: Row(
                  children: [
                    const Text('🔒', style: TextStyle(fontSize: 16)),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        'المفتاح محفوظ محلياً على جهازك فقط ولا يُرسل إلا إلى Anthropic API مباشرةً.',
                        style: GoogleFonts.ibmPlexSans(
                          fontSize: 11, color: AppColors.textSecondary, height: 1.5,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _step(String n, String text) => Padding(
        padding: const EdgeInsets.only(top: 4),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 16, height: 16,
              margin: const EdgeInsets.only(top: 1, right: 6),
              decoration: BoxDecoration(
                color: const Color(0x2200D4AA),
                borderRadius: BorderRadius.circular(4),
              ),
              child: Center(
                child: Text(n,
                  style: GoogleFonts.ibmPlexMono(
                    fontSize: 9, color: AppColors.accent, fontWeight: FontWeight.w600,
                  )),
              ),
            ),
            Expanded(
              child: Text(text,
                style: GoogleFonts.ibmPlexSans(
                  fontSize: 11, color: AppColors.textSecondary, height: 1.5,
                )),
            ),
          ],
        ),
      );
}
