// lib/screens/chat_screen.dart

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import '../models/message_model.dart';
import '../services/api_service.dart';
import '../utils/app_theme.dart';
import '../utils/system_prompt.dart';
import 'settings_screen.dart';

// ════════════════════════════════════════════════════════════════
//  CHAT SCREEN
// ════════════════════════════════════════════════════════════════
class ChatScreen extends StatefulWidget {
  final String apiKey;
  final void Function(String) onApiKeyChange;

  const ChatScreen({
    super.key,
    required this.apiKey,
    required this.onApiKeyChange,
  });

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> with TickerProviderStateMixin {
  // State
  final List<ChatMessage>     _messages   = [];
  final TextEditingController _inputCtrl  = TextEditingController();
  final ScrollController      _scroll     = ScrollController();
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  late AnthropicService       _api;

  String  _mode       = 'FOCUSED';
  bool    _loading    = false;
  int     _msgCounter = 0;
  String? _copiedId;

  // Clock
  late Timer _clockTimer;
  String _clockStr = '';
  String _dateStr  = '';

  @override
  void initState() {
    super.initState();
    _api = AnthropicService(widget.apiKey);
    _updateClock();
    _clockTimer = Timer.periodic(const Duration(seconds: 1), (_) => _updateClock());
  }

  @override
  void didUpdateWidget(ChatScreen old) {
    super.didUpdateWidget(old);
    if (old.apiKey != widget.apiKey) {
      _api = AnthropicService(widget.apiKey);
    }
  }

  @override
  void dispose() {
    _api.cancel();
    _clockTimer.cancel();
    _inputCtrl.dispose();
    _scroll.dispose();
    super.dispose();
  }

  // ── Clock ────────────────────────────────────────────────────
  void _updateClock() {
    final now = DateTime.now().toUtc().add(const Duration(hours: 2));
    setState(() {
      _clockStr = DateFormat('HH:mm:ss').format(now);
      _dateStr  = DateFormat('EEE, d MMM').format(now);
    });
  }

  // ── Helpers ──────────────────────────────────────────────────
  String _nextId() => 'msg_${++_msgCounter}';

  void _scrollToBottom({bool animated = true}) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_scroll.hasClients) return;
      final target = _scroll.position.maxScrollExtent;
      if (animated) {
        _scroll.animateTo(target,
            duration: const Duration(milliseconds: 260),
            curve: Curves.easeOut);
      } else {
        _scroll.jumpTo(target);
      }
    });
  }

  void _copyMessage(String text, String id) {
    Clipboard.setData(ClipboardData(text: text));
    setState(() => _copiedId = id);
    Future.delayed(const Duration(milliseconds: 2200),
        () => setState(() => _copiedId = null));
  }

  void _insertTemplate(String text) {
    _inputCtrl.text = text;
    Navigator.of(context).pop(); // close drawer
    FocusScope.of(context).requestFocus(FocusNode()); // unfocus
    setState(() {});
  }

  void _stopGeneration() {
    _api.cancel();
    setState(() {
      _loading = false;
      if (_messages.isNotEmpty && _messages.last.isStreaming) {
        _messages.last.isStreaming = false;
      }
    });
  }

  void _clearChat() {
    _stopGeneration();
    setState(() => _messages.clear());
  }

  // ── Open Settings ─────────────────────────────────────────────
  Future<void> _openSettings() async {
    final newKey = await Navigator.of(context).push<String>(
      MaterialPageRoute(
        builder: (_) => SettingsScreen(currentKey: widget.apiKey),
      ),
    );
    if (newKey != null) widget.onApiKeyChange(newKey);
  }

  // ── Send Message ──────────────────────────────────────────────
  Future<void> _sendMessage() async {
    final text = _inputCtrl.text.trim();
    if (text.isEmpty || _loading) return;

    _inputCtrl.clear();

    // Auto-detect mode from prefix
    String activeMode = _mode;
    String content = text;
    if (text.startsWith('///')) {
      activeMode = 'RAPID';
      content = text.substring(3).trim().isEmpty ? text : text;
    } else if (text.startsWith('//')) {
      activeMode = 'FOCUSED';
    } else if (text.startsWith('/') && !text.startsWith('//')) {
      activeMode = 'FULL';
    }
    setState(() => _mode = activeMode);

    final userMsg = ChatMessage(
      id: _nextId(),
      role: MessageRole.user,
      content: content,
      timestamp: DateTime.now(),
    );

    setState(() {
      _messages.add(userMsg);
      _loading = true;
    });
    _scrollToBottom();

    // Create assistant placeholder
    final assistantMsg = ChatMessage(
      id: _nextId(),
      role: MessageRole.assistant,
      content: '',
      timestamp: DateTime.now(),
      isStreaming: true,
    );
    setState(() => _messages.add(assistantMsg));

    _api = AnthropicService(widget.apiKey);

    await _api.streamMessage(
      history: List.from(_messages
          .where((m) => !m.isStreaming || m.id != assistantMsg.id)
          .map((m) => m)),
      activeMode: activeMode,
      onChunk: (token) {
        setState(() {
          assistantMsg.content += token;
        });
        _scrollToBottom(animated: false);
      },
      onDone: () {
        setState(() {
          assistantMsg.isStreaming = false;
          _loading = false;
        });
        _scrollToBottom();
      },
      onError: (error) {
        setState(() {
          assistantMsg.content =
              '❌ خطأ في الاتصال\n\n$error\n\nتحقق من:\n'
              '• اتصال الإنترنت\n'
              '• صحة الـ API Key\n'
              '• الرصيد المتاح في حساب Anthropic';
          assistantMsg.isStreaming = false;
          assistantMsg.isError = true;
          _loading = false;
        });
        _scrollToBottom();
      },
    );
  }

  // ════════════════════════════════════════════════════════════════
  //  BUILD
  // ════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: AppColors.background,
      drawer: _buildDrawer(),
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(),
            const SizedBox(height: 1),
            Expanded(child: _buildMessageArea()),
            _buildInputArea(),
          ],
        ),
      ),
    );
  }

  // ─── HEADER ─────────────────────────────────────────────────
  Widget _buildHeader() {
    final modeColor  = AppColors.modeColor(_mode);
    final modeBg     = AppColors.modeBg(_mode);
    final modeBorder = AppColors.modeBorder(_mode);
    final m = kModes.firstWhere((x) => x.id == _mode);

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: const Color(0xF7070D1A),
        border: Border(
          bottom: BorderSide(color: AppColors.border, width: 1),
        ),
      ),
      child: Row(
        children: [
          // Hamburger
          GestureDetector(
            onTap: () => _scaffoldKey.currentState?.openDrawer(),
            child: Container(
              padding: const EdgeInsets.all(6),
              child: Icon(Icons.menu, color: AppColors.textSecondary, size: 20),
            ),
          ),
          const SizedBox(width: 8),

          // Logo
          Container(
            width: 32, height: 32,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF00D4AA), Color(0xFF0087CC)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(8),
              boxShadow: [BoxShadow(color: AppColors.accent.withOpacity(0.25), blurRadius: 8)],
            ),
            child: const Center(child: Text('⚕', style: TextStyle(fontSize: 17))),
          ),
          const SizedBox(width: 9),

          // Title
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'ELITE ENDO AI',
                  style: GoogleFonts.syne(
                    fontSize: 13.5, fontWeight: FontWeight.w800,
                    color: AppColors.textPrimary, letterSpacing: 0.5,
                  ),
                ),
                Text(
                  'v5.0 · Zero-Hallucination Protocol',
                  style: GoogleFonts.ibmPlexMono(
                    fontSize: 8.5, color: AppColors.accent.withOpacity(0.6),
                    letterSpacing: 0.8,
                  ),
                ),
              ],
            ),
          ),

          // Mode badge
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
            decoration: BoxDecoration(
              color: modeBg,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: modeBorder),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(m.emoji, style: const TextStyle(fontSize: 11)),
                const SizedBox(width: 4),
                Text(
                  m.label,
                  style: GoogleFonts.syne(
                    fontSize: 9.5, fontWeight: FontWeight.w800,
                    color: modeColor, letterSpacing: 0.8,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),

          // Clock
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                _clockStr,
                style: GoogleFonts.ibmPlexMono(
                  fontSize: 11, color: AppColors.accent,
                  fontWeight: FontWeight.w500, letterSpacing: 0.5,
                ),
              ),
              Text(
                _dateStr,
                style: GoogleFonts.ibmPlexMono(
                  fontSize: 7.5, color: AppColors.textMuted,
                ),
              ),
            ],
          ),
          const SizedBox(width: 6),

          // Settings icon
          GestureDetector(
            onTap: _openSettings,
            child: Container(
              padding: const EdgeInsets.all(5),
              decoration: BoxDecoration(
                color: const Color(0x0AFFFFFF),
                borderRadius: BorderRadius.circular(6),
              ),
              child: const Icon(Icons.settings_outlined,
                  color: AppColors.textSecondary, size: 16),
            ),
          ),
        ],
      ),
    );
  }

  // ─── DRAWER / SIDEBAR ────────────────────────────────────────
  Widget _buildDrawer() {
    return Drawer(
      child: Container(
        color: const Color(0xFF040810),
        child: ListView(
          padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
          children: [
            // Header
            Padding(
              padding: const EdgeInsets.only(bottom: 14, top: 6, left: 4),
              child: Text(
                'د. نادر — العيادة',
                style: GoogleFonts.syne(
                  fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.textPrimary,
                ),
              ),
            ),

            _drawerLabel('Analysis Mode'),
            const SizedBox(height: 6),
            ...kModes.map((m) => _buildModeItem(m)),

            const SizedBox(height: 16),
            const Divider(color: AppColors.borderSubtle, height: 1),
            const SizedBox(height: 14),

            _drawerLabel('Quick Templates'),
            const SizedBox(height: 6),
            ...kTemplates.map((t) => _buildTemplateItem(t)),

            const SizedBox(height: 16),
            const Divider(color: AppColors.borderSubtle, height: 1),
            const SizedBox(height: 14),

            _drawerLabel('Mode Shortcuts'),
            const SizedBox(height: 6),
            ...[
              ['/',   '🔴 FULL — 12 خطوة'],
              ['//',  '🟡 FOCUSED — 6 خطوات'],
              ['///', '🟢 RAPID — فوري'],
            ].map((row) => _buildShortcutRow(row[0], row[1])),

            const SizedBox(height: 20),

            // Session / clear
            if (_messages.isNotEmpty) ...[
              const Divider(color: AppColors.borderSubtle, height: 1),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: const Color(0x0A00D4AA),
                  borderRadius: BorderRadius.circular(9),
                  border: Border.all(color: const Color(0x1200D4AA)),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      '${_messages.where((m) => m.role == MessageRole.user).length} سؤال · ${_messages.length} رسالة',
                      style: GoogleFonts.ibmPlexSans(
                          fontSize: 10.5, color: AppColors.textSecondary),
                    ),
                    GestureDetector(
                      onTap: () {
                        _clearChat();
                        Navigator.of(context).pop();
                      },
                      child: Text(
                        'مسح المحادثة ×',
                        style: GoogleFonts.ibmPlexSans(
                            fontSize: 10.5, color: AppColors.errorColor.withOpacity(0.7)),
                      ),
                    ),
                  ],
                ),
              ),
            ],

            const SizedBox(height: 20),
            // Version note
            Center(
              child: Text(
                'Anti-Hallucination: ACTIVE ✓\nEgyptian Pharma Context ✓',
                textAlign: TextAlign.center,
                style: GoogleFonts.ibmPlexMono(
                    fontSize: 8.5, color: AppColors.textMuted, height: 1.6),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _drawerLabel(String text) => Padding(
        padding: const EdgeInsets.only(left: 4, bottom: 2),
        child: Text(
          text.toUpperCase(),
          style: GoogleFonts.ibmPlexSans(
            fontSize: 8.5, fontWeight: FontWeight.w600,
            color: AppColors.textMuted, letterSpacing: 1.4,
          ),
        ),
      );

  Widget _buildModeItem(EndoMode m) {
    final isActive = _mode == m.id;
    return GestureDetector(
      onTap: () {
        setState(() => _mode = m.id);
        Navigator.of(context).pop();
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        margin: const EdgeInsets.only(bottom: 5),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
        decoration: BoxDecoration(
          color: isActive ? AppColors.modeBg(m.id) : Colors.transparent,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: isActive ? AppColors.modeBorder(m.id) : AppColors.borderSubtle,
          ),
        ),
        child: Row(
          children: [
            Text(m.emoji, style: const TextStyle(fontSize: 16)),
            const SizedBox(width: 9),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    m.label,
                    style: GoogleFonts.syne(
                      fontSize: 11.5, fontWeight: FontWeight.w800,
                      color: isActive ? AppColors.modeColor(m.id) : AppColors.textSecondary,
                      letterSpacing: 0.5,
                    ),
                  ),
                  Text(
                    '${m.steps} · ${m.description}',
                    style: GoogleFonts.ibmPlexSans(
                        fontSize: 9.5, color: AppColors.textMuted),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTemplateItem(CaseTemplate t) => GestureDetector(
        onTap: () => _insertTemplate(t.text),
        child: Container(
          margin: const EdgeInsets.only(bottom: 4),
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
          decoration: BoxDecoration(
            color: const Color(0x05FFFFFF),
            borderRadius: BorderRadius.circular(7),
            border: Border.all(color: AppColors.borderSubtle),
          ),
          child: Row(
            children: [
              Text(t.icon, style: const TextStyle(fontSize: 14)),
              const SizedBox(width: 8),
              Text(
                t.label,
                style: GoogleFonts.ibmPlexSans(
                    fontSize: 11, color: AppColors.textSecondary),
              ),
            ],
          ),
        ),
      );

  Widget _buildShortcutRow(String key, String label) => Padding(
        padding: const EdgeInsets.only(bottom: 5, left: 4),
        child: Row(
          children: [
            Text(
              key,
              style: GoogleFonts.ibmPlexMono(
                  fontSize: 11, color: AppColors.accentDim, fontWeight: FontWeight.w600),
            ),
            const SizedBox(width: 10),
            Text(
              label,
              style: GoogleFonts.ibmPlexSans(
                  fontSize: 10.5, color: AppColors.textMuted),
            ),
          ],
        ),
      );

  // ─── MESSAGE AREA ────────────────────────────────────────────
  Widget _buildMessageArea() {
    if (_messages.isEmpty) return _buildWelcome();

    return ListView.builder(
      controller: _scroll,
      padding: const EdgeInsets.fromLTRB(14, 16, 14, 8),
      itemCount: _messages.length,
      itemBuilder: (ctx, i) => _buildMessageBubble(_messages[i]),
    );
  }

  Widget _buildWelcome() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        children: [
          const SizedBox(height: 30),
          // Logo glow
          Container(
            width: 72, height: 72,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0x1E00D4AA), Color(0x1E0087CC)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: AppColors.border),
              boxShadow: [
                BoxShadow(color: AppColors.accent.withOpacity(0.12), blurRadius: 28),
              ],
            ),
            child: const Center(child: Text('⚕', style: TextStyle(fontSize: 36))),
          ),
          const SizedBox(height: 20),
          Text(
            'مرحباً د. نادر',
            style: GoogleFonts.syne(
              fontSize: 22, fontWeight: FontWeight.w800, color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'ELITE ENDOCRINOLOGY AI v5.0 جاهز للعمل',
            textAlign: TextAlign.center,
            style: GoogleFonts.ibmPlexSans(
                fontSize: 12.5, color: AppColors.textSecondary, height: 1.5),
          ),
          Text(
            'Academic Grand Round · Zero-Hallucination · Egyptian Pharma',
            textAlign: TextAlign.center,
            style: GoogleFonts.ibmPlexSans(
                fontSize: 10.5, color: AppColors.textMuted, height: 1.5),
          ),
          const SizedBox(height: 28),

          // Mode cards
          Row(
            children: kModes.map((m) => Expanded(
              child: GestureDetector(
                onTap: () => setState(() => _mode = m.id),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 180),
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
                  decoration: BoxDecoration(
                    color: AppColors.modeBg(m.id),
                    borderRadius: BorderRadius.circular(11),
                    border: Border.all(color: AppColors.modeBorder(m.id)),
                  ),
                  child: Column(
                    children: [
                      Text(m.emoji, style: const TextStyle(fontSize: 20)),
                      const SizedBox(height: 5),
                      Text(
                        m.label,
                        style: GoogleFonts.syne(
                          fontSize: 10, fontWeight: FontWeight.w800,
                          color: AppColors.modeColor(m.id), letterSpacing: 0.6,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        m.description,
                        textAlign: TextAlign.center,
                        style: GoogleFonts.ibmPlexSans(
                            fontSize: 8.5, color: AppColors.textMuted, height: 1.4),
                      ),
                    ],
                  ),
                ),
              ),
            )).toList(),
          ),
          const SizedBox(height: 22),

          // Quick examples
          _drawerLabel('أمثلة سريعة'),
          const SizedBox(height: 8),
          Wrap(
            spacing: 7, runSpacing: 7,
            children: kExamples.map((q) => GestureDetector(
              onTap: () {
                _inputCtrl.text = q;
                setState(() {});
              },
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 6),
                decoration: BoxDecoration(
                  color: const Color(0x08FFFFFF),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: const Color(0x1400D4AA)),
                ),
                child: Text(
                  q,
                  style: GoogleFonts.ibmPlexSans(
                      fontSize: 10.5, color: AppColors.textSecondary),
                ),
              ),
            )).toList(),
          ),

          const SizedBox(height: 30),
          // No API key warning
          if (widget.apiKey.isEmpty) ...[
            GestureDetector(
              onTap: _openSettings,
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: const Color(0x10FF4757),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: const Color(0x30FF4757)),
                ),
                child: Row(
                  children: [
                    const Text('⚠️', style: TextStyle(fontSize: 16)),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        'لم يتم تعيين API Key بعد. اضغط هنا لإضافته.',
                        style: GoogleFonts.ibmPlexSans(
                            fontSize: 11.5, color: AppColors.errorColor.withOpacity(0.8)),
                      ),
                    ),
                    const Icon(Icons.arrow_forward_ios,
                        color: AppColors.errorColor, size: 13),
                  ],
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildMessageBubble(ChatMessage msg) {
    final isUser = msg.role == MessageRole.user;

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: isUser ? MainAxisAlignment.end : MainAxisAlignment.start,
        children: [
          // AI avatar
          if (!isUser) ...[
            Container(
              width: 26, height: 26,
              margin: const EdgeInsets.only(top: 2, right: 7),
              decoration: BoxDecoration(
                gradient: msg.isError
                    ? null
                    : const LinearGradient(
                        colors: [Color(0x2500D4AA), Color(0x200087CC)]),
                color: msg.isError ? const Color(0x20FF4757) : null,
                borderRadius: BorderRadius.circular(7),
                border: Border.all(
                    color: msg.isError
                        ? const Color(0x35FF4757)
                        : AppColors.border),
              ),
              child: Center(
                child: msg.isStreaming
                    ? _ThreeDots()
                    : Text(
                        msg.isError ? '⚠' : '⚕',
                        style: const TextStyle(fontSize: 13),
                      ),
              ),
            ),
          ],

          // Bubble
          Flexible(
            child: Column(
              crossAxisAlignment: isUser ? CrossAxisAlignment.end : CrossAxisAlignment.start,
              children: [
                Container(
                  constraints: BoxConstraints(
                    maxWidth: MediaQuery.of(context).size.width * (isUser ? 0.75 : 0.88),
                  ),
                  padding: EdgeInsets.symmetric(
                    horizontal: isUser ? 13 : 14,
                    vertical: isUser ? 10 : 13,
                  ),
                  decoration: BoxDecoration(
                    color: isUser
                        ? const Color(0x1800D4AA)
                        : msg.isError
                            ? const Color(0x10FF4757)
                            : const Color(0xF00C1424),
                    borderRadius: BorderRadius.only(
                      topLeft: const Radius.circular(14),
                      topRight: const Radius.circular(14),
                      bottomLeft: Radius.circular(isUser ? 14 : 3),
                      bottomRight: Radius.circular(isUser ? 3 : 14),
                    ),
                    border: Border.all(
                      color: isUser
                          ? const Color(0x2E00D4AA)
                          : msg.isError
                              ? const Color(0x28FF4757)
                              : AppColors.borderSubtle,
                    ),
                    boxShadow: isUser
                        ? []
                        : [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.22),
                              blurRadius: 12, offset: const Offset(0, 2),
                            )
                          ],
                  ),
                  child: msg.content.isEmpty && msg.isStreaming
                      ? _ThreeDots()
                      : SelectableText(
                          msg.content,
                          style: GoogleFonts.ibmPlexMono(
                            fontSize: isUser ? 13 : 11.5,
                            color: isUser ? AppColors.textPrimary : const Color(0xFFB0C8E0),
                            height: 1.72,
                          ),
                          textDirection: TextDirection.ltr,
                        ),
                ),

                // Timestamp + copy
                Padding(
                  padding: const EdgeInsets.only(top: 3, left: 2, right: 2),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        DateFormat('HH:mm').format(
                          msg.timestamp.toUtc().add(const Duration(hours: 2)),
                        ),
                        style: GoogleFonts.ibmPlexMono(
                            fontSize: 8.5, color: AppColors.textMuted),
                      ),
                      if (!isUser && !msg.isStreaming && msg.content.isNotEmpty) ...[
                        const SizedBox(width: 8),
                        GestureDetector(
                          onTap: () => _copyMessage(msg.content, msg.id),
                          child: Text(
                            _copiedId == msg.id ? '✓ تم النسخ' : 'نسخ',
                            style: GoogleFonts.ibmPlexSans(
                              fontSize: 8.5,
                              color: _copiedId == msg.id
                                  ? AppColors.accent
                                  : AppColors.textMuted,
                            ),
                          ),
                        ),
                      ],
                      if (msg.isStreaming) ...[
                        const SizedBox(width: 8),
                        Text(
                          'جاري التحليل...',
                          style: GoogleFonts.ibmPlexSans(
                              fontSize: 8.5, color: AppColors.accentDim),
                        ),
                      ],
                    ],
                  ),
                ),
              ],
            ),
          ),

          // User avatar
          if (isUser) ...[
            Container(
              width: 26, height: 26,
              margin: const EdgeInsets.only(top: 2, left: 7),
              decoration: BoxDecoration(
                color: const Color(0x0E00D4AA),
                borderRadius: BorderRadius.circular(7),
                border: Border.all(color: const Color(0x1E00D4AA)),
              ),
              child: Center(
                child: Text(
                  'ن',
                  style: GoogleFonts.syne(
                      fontSize: 11, fontWeight: FontWeight.w700,
                      color: AppColors.textSecondary),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  // ─── INPUT AREA ──────────────────────────────────────────────
  Widget _buildInputArea() {
    final m = kModes.firstWhere((x) => x.id == _mode);

    return Container(
      decoration: BoxDecoration(
        color: const Color(0xF7050A14),
        border: Border(top: BorderSide(color: AppColors.border, width: 1)),
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 10),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Mode tabs
              SizedBox(
                height: 26,
                child: Row(
                  children: [
                    ...kModes.map((mo) => GestureDetector(
                          onTap: () => setState(() => _mode = mo.id),
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 160),
                            margin: const EdgeInsets.only(right: 5),
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: _mode == mo.id
                                  ? AppColors.modeBg(mo.id)
                                  : Colors.transparent,
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color: _mode == mo.id
                                    ? AppColors.modeBorder(mo.id)
                                    : AppColors.borderSubtle,
                              ),
                            ),
                            child: Text(
                              '${mo.emoji} ${mo.label}',
                              style: GoogleFonts.syne(
                                fontSize: 9, fontWeight: FontWeight.w800,
                                color: _mode == mo.id
                                    ? AppColors.modeColor(mo.id)
                                    : AppColors.textMuted,
                                letterSpacing: 0.5,
                              ),
                            ),
                          ),
                        )),

                    const Spacer(),

                    // Stop button
                    if (_loading)
                      GestureDetector(
                        onTap: _stopGeneration,
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 9, vertical: 4),
                          decoration: BoxDecoration(
                            color: const Color(0x12FF4757),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: const Color(0x30FF4757)),
                          ),
                          child: Text(
                            '⏹ إيقاف',
                            style: GoogleFonts.ibmPlexSans(
                                fontSize: 9,
                                color: AppColors.errorColor.withOpacity(0.8),
                                fontWeight: FontWeight.w600),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 7),

              // Textarea + send
              Container(
                decoration: BoxDecoration(
                  color: AppColors.surface,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AppColors.border),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _inputCtrl,
                        maxLines: 5,
                        minLines: 2,
                        enabled: !_loading,
                        textInputAction: TextInputAction.newline,
                        textDirection: TextDirection.ltr,
                        style: GoogleFonts.ibmPlexSans(
                          fontSize: 13, color: AppColors.textPrimary, height: 1.6,
                        ),
                        decoration: InputDecoration(
                          hintText:
                              '${m.emoji} ${m.label} نشط — اكتب سؤالك أو استخدم Template…',
                          hintStyle: GoogleFonts.ibmPlexSans(
                              fontSize: 11.5, color: AppColors.textMuted),
                          border: InputBorder.none,
                          enabledBorder: InputBorder.none,
                          focusedBorder: InputBorder.none,
                          contentPadding: const EdgeInsets.fromLTRB(13, 11, 6, 11),
                          filled: false,
                        ),
                        onChanged: (_) => setState(() {}),
                      ),
                    ),
                    // Send button
                    Padding(
                      padding: const EdgeInsets.all(5),
                      child: GestureDetector(
                        onTap: (_loading || _inputCtrl.text.trim().isEmpty)
                            ? null
                            : _sendMessage,
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 160),
                          width: 44, height: 44,
                          decoration: BoxDecoration(
                            gradient: (_loading || _inputCtrl.text.trim().isEmpty)
                                ? null
                                : const LinearGradient(
                                    colors: [
                                      Color(0x2E00D4AA),
                                      Color(0x220087CC)
                                    ],
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                  ),
                            color: (_loading || _inputCtrl.text.trim().isEmpty)
                                ? const Color(0x05FFFFFF)
                                : null,
                            borderRadius: BorderRadius.circular(9),
                            border: Border.all(
                              color: (_loading || _inputCtrl.text.trim().isEmpty)
                                  ? AppColors.borderSubtle
                                  : AppColors.border,
                            ),
                          ),
                          child: _loading
                              ? Center(child: _ThreeDots())
                              : Icon(
                                  Icons.arrow_upward,
                                  color: _inputCtrl.text.trim().isEmpty
                                      ? AppColors.textMuted
                                      : AppColors.accent,
                                  size: 20,
                                ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              // Status bar
              Padding(
                padding: const EdgeInsets.only(top: 5),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      '⚕ ELITE ENDO v5.0 · Anti-Hallucination ACTIVE ✓',
                      style: GoogleFonts.ibmPlexMono(
                          fontSize: 7.5, color: AppColors.textMuted),
                    ),
                    Text(
                      'ADA 2026 · Williams 14th · ISPAD 2022',
                      style: GoogleFonts.ibmPlexMono(
                          fontSize: 7.5, color: AppColors.textMuted),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── THREE DOTS INDICATOR ────────────────────────────────────
class _ThreeDots extends StatefulWidget {
  @override
  State<_ThreeDots> createState() => _ThreeDotsState();
}

class _ThreeDotsState extends State<_ThreeDots> with TickerProviderStateMixin {
  late final List<AnimationController> _controllers;
  late final List<Animation<double>> _animations;

  @override
  void initState() {
    super.initState();
    _controllers = List.generate(3, (i) => AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    ));
    _animations = _controllers.map((c) => Tween(begin: 0.3, end: 1.0).animate(
      CurvedAnimation(parent: c, curve: Curves.easeInOut),
    )).toList();

    for (int i = 0; i < 3; i++) {
      Future.delayed(Duration(milliseconds: i * 180), () {
        if (mounted) {
          _controllers[i].repeat(reverse: true);
        }
      });
    }
  }

  @override
  void dispose() {
    for (final c in _controllers) c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(3, (i) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 1.5),
        child: FadeTransition(
          opacity: _animations[i],
          child: Container(
            width: 5, height: 5,
            decoration: BoxDecoration(
              color: AppColors.accentDim,
              shape: BoxShape.circle,
            ),
          ),
        ),
      )),
    );
  }
}
