// lib/services/api_service.dart

import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/message_model.dart';
import '../utils/system_prompt.dart';
import 'package:intl/intl.dart';

class AnthropicService {
  static const _baseUrl = 'https://api.anthropic.com/v1/messages';
  static const _model   = 'claude-sonnet-4-20250514';
  static const _maxTok  = 4096;

  final String apiKey;
  http.Client? _client;

  AnthropicService(this.apiKey);

  /// Cancel any in-flight request
  void cancel() {
    _client?.close();
    _client = null;
  }

  /// Stream tokens from Anthropic SSE.
  /// [onChunk] fires on every new text token.
  /// [onDone] fires when stream is complete.
  /// [onError] fires on any error.
  Future<void> streamMessage({
    required List<ChatMessage> history,
    required String activeMode,
    required void Function(String token) onChunk,
    required void Function() onDone,
    required void Function(String error) onError,
  }) async {
    cancel(); // close any existing client
    _client = http.Client();

    // Build Egypt-time context addendum
    final now = DateTime.now().toUtc().add(const Duration(hours: 2));
    final dateStr = DateFormat('EEEE, d MMM yyyy – HH:mm').format(now);
    final modeNote = 'Active Mode: $activeMode\nEgypt Time: $dateStr (UTC+2)\nUser: Dr. Nader';

    final systemWithContext = '$kSystemPrompt\n\n$modeNote';

    final body = jsonEncode({
      'model': _model,
      'max_tokens': _maxTok,
      'stream': true,
      'system': systemWithContext,
      'messages': history.map((m) => m.toApi()).toList(),
    });

    try {
      final request = http.Request('POST', Uri.parse(_baseUrl));
      request.headers.addAll({
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      });
      request.body = body;

      final response = await _client!.send(request);

      if (response.statusCode != 200) {
        final errorBody = await response.stream.bytesToString();
        String msg = 'HTTP ${response.statusCode}';
        try {
          final j = jsonDecode(errorBody);
          msg = j['error']?['message'] ?? msg;
        } catch (_) {}
        onError(msg);
        return;
      }

      // Buffer for partial SSE lines
      String buffer = '';

      await for (final chunk in response.stream.transform(utf8.decoder)) {
        buffer += chunk;
        final lines = buffer.split('\n');
        buffer = lines.removeLast(); // last may be partial

        for (final line in lines) {
          if (!line.startsWith('data: ')) continue;
          final raw = line.substring(6).trim();
          if (raw == '[DONE]') {
            onDone();
            return;
          }
          try {
            final event = jsonDecode(raw);
            if (event['type'] == 'content_block_delta') {
              final text = event['delta']?['text'] as String?;
              if (text != null && text.isNotEmpty) {
                onChunk(text);
              }
            }
          } catch (_) {
            // ignore malformed SSE lines
          }
        }
      }

      onDone();
    } on http.ClientException catch (e) {
      if (e.message.contains('Connection closed') ||
          e.message.contains('Software caused') ||
          e.message.isEmpty) {
        // user cancelled — not an error
      } else {
        onError(e.message);
      }
    } catch (e) {
      final msg = e.toString();
      if (msg.contains('cancelled') || msg.contains('abort')) return;
      onError(msg);
    }
  }
}
