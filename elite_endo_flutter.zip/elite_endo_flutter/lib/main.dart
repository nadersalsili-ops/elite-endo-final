// lib/main.dart

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'utils/app_theme.dart';
import 'screens/chat_screen.dart';
import 'screens/settings_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Force portrait orientation
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
    DeviceOrientation.landscapeLeft,
    DeviceOrientation.landscapeRight,
  ]);

  // Status bar style
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: Color(0xFF070D1A),
    systemNavigationBarIconBrightness: Brightness.light,
  ));

  runApp(const EliteEndoApp());
}

// ════════════════════════════════════════════════════════════════
//  ROOT APP
// ════════════════════════════════════════════════════════════════
class EliteEndoApp extends StatefulWidget {
  const EliteEndoApp({super.key});

  @override
  State<EliteEndoApp> createState() => _EliteEndoAppState();
}

class _EliteEndoAppState extends State<EliteEndoApp> {
  String _apiKey = '';
  bool   _loaded = false;

  @override
  void initState() {
    super.initState();
    _loadApiKey();
  }

  Future<void> _loadApiKey() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _apiKey = prefs.getString('anthropic_api_key') ?? '';
      _loaded = true;
    });
  }

  void _updateApiKey(String key) => setState(() => _apiKey = key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ELITE ENDO AI v5.0',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.dark,
      home: !_loaded
          ? const _SplashScreen()
          : _apiKey.isEmpty
              ? _FirstRunWrapper(onKeySet: _updateApiKey)
              : ChatScreen(
                  apiKey: _apiKey,
                  onApiKeyChange: _updateApiKey,
                ),
    );
  }
}

// ─── SPLASH SCREEN ───────────────────────────────────────────
class _SplashScreen extends StatelessWidget {
  const _SplashScreen();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 72, height: 72,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF00D4AA), Color(0xFF0087CC)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                      color: const Color(0xFF00D4AA).withOpacity(0.3),
                      blurRadius: 24),
                ],
              ),
              child: const Center(
                child: Text('⚕', style: TextStyle(fontSize: 36)),
              ),
            ),
            const SizedBox(height: 20),
            const CircularProgressIndicator(
              strokeWidth: 2,
              color: Color(0xFF00D4AA),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── FIRST-RUN WRAPPER (no API key yet) ──────────────────────
class _FirstRunWrapper extends StatelessWidget {
  final void Function(String) onKeySet;
  const _FirstRunWrapper({required this.onKeySet});

  @override
  Widget build(BuildContext context) {
    return SettingsScreen(
      currentKey: null,
    );
  }
}
