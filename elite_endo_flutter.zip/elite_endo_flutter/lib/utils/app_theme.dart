// lib/utils/app_theme.dart

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

// ─── PALETTE ─────────────────────────────────────────────────
class AppColors {
  static const background     = Color(0xFF070D1A);
  static const surface        = Color(0xFF0C1424);
  static const surfaceAlt     = Color(0xFF0A1020);
  static const accent         = Color(0xFF00D4AA);
  static const accentDim      = Color(0xFF00A070);
  static const secondary      = Color(0xFF0087CC);
  static const textPrimary    = Color(0xFFB8D0E8);
  static const textSecondary  = Color(0xFF3A5870);
  static const textMuted      = Color(0xFF1A3048);
  static const border         = Color(0x2400D4AA);
  static const borderSubtle   = Color(0x0AFFFFFF);
  static const errorColor     = Color(0xFFFF4757);

  // Mode colors
  static const fullRed        = Color(0xFFFF4757);
  static const focusedAmber   = Color(0xFFFFA502);
  static const rapidTeal      = Color(0xFF00D4AA);

  static Color modeColor(String mode) {
    switch (mode) {
      case 'FULL':    return fullRed;
      case 'FOCUSED': return focusedAmber;
      case 'RAPID':   return rapidTeal;
      default:        return rapidTeal;
    }
  }

  static Color modeBg(String mode) {
    switch (mode) {
      case 'FULL':    return const Color(0x1AFF4757);
      case 'FOCUSED': return const Color(0x1AFFA502);
      case 'RAPID':   return const Color(0x1A00D4AA);
      default:        return const Color(0x1A00D4AA);
    }
  }

  static Color modeBorder(String mode) {
    switch (mode) {
      case 'FULL':    return const Color(0x47FF4757);
      case 'FOCUSED': return const Color(0x47FFA502);
      case 'RAPID':   return const Color(0x4700D4AA);
      default:        return const Color(0x4700D4AA);
    }
  }
}

// ─── THEME ───────────────────────────────────────────────────
class AppTheme {
  static ThemeData get dark => ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: AppColors.background,
        colorScheme: const ColorScheme.dark(
          surface: AppColors.surface,
          primary: AppColors.accent,
          secondary: AppColors.secondary,
          error: AppColors.errorColor,
        ),
        textTheme: GoogleFonts.ibmPlexSansTextTheme(
          ThemeData.dark().textTheme,
        ).apply(
          bodyColor: AppColors.textPrimary,
          displayColor: AppColors.textPrimary,
        ),
        appBarTheme: AppBarTheme(
          backgroundColor: AppColors.background,
          elevation: 0,
          titleTextStyle: GoogleFonts.syne(
            fontSize: 16,
            fontWeight: FontWeight.w800,
            color: AppColors.textPrimary,
            letterSpacing: 0.5,
          ),
        ),
        drawerTheme: const DrawerThemeData(
          backgroundColor: Color(0xFF05080F),
          scrimColor: Color(0x8A000000),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: AppColors.surface,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: AppColors.border),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: AppColors.border),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: AppColors.accent, width: 1.5),
          ),
          hintStyle: const TextStyle(color: AppColors.textMuted, fontSize: 13),
        ),
      );
}
